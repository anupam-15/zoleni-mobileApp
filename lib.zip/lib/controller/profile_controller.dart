
import 'dart:convert';

import 'package:image_picker/image_picker.dart';
import 'package:zoleni/Network/api_functions.dart';
import 'package:zoleni/model/order_list_model.dart';

import '../exports/get_export.dart';
import '../exports/globle_exports.dart';
import '../model/country_list_model.dart';


class ProfileController extends GetxController{
  String? selectGender;
  String? selectOrderType;
  String? selectCountry;
  String? selectState;
  final ImagePicker _picker = ImagePicker();
  XFile? selectedImage;
  String? imageName;
  TextEditingController imagePathController = TextEditingController();
  TextEditingController firstNameTextController = TextEditingController();
  TextEditingController lastNameTextController = TextEditingController();
  TextEditingController stateNameTextController = TextEditingController();
  TextEditingController cityNameTextController = TextEditingController();


  TextEditingController newPasswordTextController = TextEditingController();



  Future<List<Datum>> getCountryList() async {
    var response = await ApiFunction().getMethod(ApiFunction.countryList);
    print('CountryListResponse');
    print(response);
    CountryListModel countryListModel = CountryListModel.fromJson(jsonDecode(response.body));
    update();
    if(countryListModel.data.data == []){
      update();
      return [];
    }else{
      List<Datum> countryList = countryListModel.data.data;
      update();
      return countryList;
    }
  }
  Future<List<dynamic>> getOrderList() async {
    var response = await ApiFunction().getMethod(ApiFunction.orderList);
    debugPrint('OrderListResponse');
    //debugPrint(response.body);
    OrderListModel orderListModel = OrderListModel.fromJson(jsonDecode(response.body));
    print(orderListModel.status);
    update();
    return orderListModel.data.data;
/*    if(orderListModel.data.data == []){
      update();
      return [];
    }else{
      List<Order> orderList = orderListModel.data.data;
      update();
      print('orderList');
      print(orderList);
      return orderList;
    }*/
  return [];
  }
  Future<void> pickImage() async {
    final pickedImage = await _picker.pickImage(source: ImageSource.gallery);

      selectedImage = pickedImage;
      if (pickedImage != null) {
        imageName = pickedImage.name;
        imagePathController.text = pickedImage.path;
      }
      update();
  }

  Future<String> updateProfile(
      String userId,
      String fname,
      String lname,
      String gender,
      String image,
      String country,
      String state,
      String city,
      ) async {
    var json = {
      'user_id': userId,
      'fname':fname,
      'lname': lname,
      'gender': gender,
      'image': image,
      'country': country,
      'state': state,
      'city': city,
      'dob' :""
    };
    var response = await ApiFunction().globalMethod(ApiFunction.forgotPasswordAndProfileUpdate,json);
    //debugPrint(response.body);
    return jsonDecode(response.body)['err'];
    //update();
  }
}