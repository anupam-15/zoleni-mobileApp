
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:zoleni/Network/api_functions.dart';
import 'package:zoleni/controller/home_controller.dart';
import 'package:zoleni/model/signup_response_model.dart';
import '../model/login_response_model.dart';

class AuthController extends GetxController{
  TextEditingController businessTypeController = TextEditingController(
      text: 'businessNameController'
  );
  TextEditingController businessNameController = TextEditingController(text: 'firstnameController');
  TextEditingController firstnameController = TextEditingController(text: 'ftext');
  TextEditingController lastnameController = TextEditingController(text: 'ltext');
  TextEditingController emailController = TextEditingController(text: 'vidurpersonal@gmail.com');
  TextEditingController passwordController = TextEditingController(text: '9876543210');
  TextEditingController rePasswordController = TextEditingController();
  bool isBusiness = false;
  bool showBusinessNameField = false;
  bool isAgreed = false;


  bool emailValidate(String value){
    if(value.isEmail){
      return true;
    }else{
      return false;
    }
  }
  /*
  //Future<LoginResponseModel> loginWithEmailAndPassword(String email,String password) async {
  Future<LoginData> loginWithEmailAndPassword(String email,String password) async {
    var json = {
      'email': email,
      'password':password
    };
    var response = await ApiFunction().globalMethod(ApiFunction.login,json);
    debugPrint(response.body);
    //LoginResponseModel loginResponseModel = LoginResponseModel.fromJson(jsonDecode(response.body));
    LoginData loginData =  LoginData.fromJson(jsonDecode(response.body));
    update();
     // return loginResponseModel;
      return loginData;
  }*/
  //Future<LoginResponseModel> loginWithEmailAndPassword(String email,String password) async {
  Future<LoginData> loginWithEmailAndPassword(String email,String password) async {
    var json = {
      'email': email,
      'password':password
    };
    var response = await ApiFunction().globalMethod(ApiFunction.login,json);
    //debugPrint(response.body);
    LoginResponseModel loginResponseModel = LoginResponseModel.fromJson(jsonDecode(response.body));
    List<LoginData> datumList = loginResponseModel.data.data;
    print(datumList);
    if(datumList[0].userId.isNotEmpty && datumList[0].userId.isNumericOnly && datumList[0].userId != ''){
      update();
      return datumList[0];
    }else{
      Get.back();
      throw response.reasonPhrase.toString();

    }
    //LoginResponseModel loginResponseModel = LoginResponseModel.fromJson(jsonDecode(response.body));

   // print(loginData[0]['id']);
    //String userId = loginData[0]['id'];
    //update();

  }
  Future<LoginData> forgotPassword(String email) async {
    var json = {
      'email': email,
    };
    var response = await ApiFunction().globalMethod(ApiFunction.login,json);
    //debugPrint(response.body);
    LoginResponseModel loginResponseModel = LoginResponseModel.fromJson(jsonDecode(response.body));
    List<LoginData> datumList = loginResponseModel.data.data;
    if(datumList[0].userId.isNotEmpty && datumList[0].userId.isNumericOnly && datumList[0].userId != ''){
      update();
      return datumList[0];
    }else{
      throw response.reasonPhrase.toString();
    }
    //LoginResponseModel loginResponseModel = LoginResponseModel.fromJson(jsonDecode(response.body));

   // print(loginData[0]['id']);
    //String userId = loginData[0]['id'];
    //update();

  }
  Future<bool> changePassword(
      String userId,
      String newPassword,
      ) async {
    var json = {
      'user_id': userId,
      'password':newPassword
    };
    var response = await ApiFunction().globalMethod(ApiFunction.forgotPasswordAndProfileUpdate,json);
    //debugPrint(response.body);

    return true;

    //update();

  }





  Future<LoginData> registerAuth(
      String type,String fname,String lname,
      String email,String password) async {
    var json = {
    'type' : 'personal',
    'fname': fname,
      'lname': lname,
      'email' : email,
      'password' : password,
      'ip' : '76217',
      'postdate' : DateTime.now().toIso8601String()
    };
    var response = await ApiFunction().globalMethod(ApiFunction.register, json);
    //debugPrint(response.body);
    SignUpResponseModel signUpResponseModel = SignUpResponseModel.fromJson(jsonDecode(response.body));
    if(signUpResponseModel.data.id != 0){
      LoginData loginData = await loginWithEmailAndPassword(email, password);
      update();
      return loginData;
    }else{
     throw response.reasonPhrase.toString();
    }
  }
}
