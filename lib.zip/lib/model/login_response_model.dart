// To parse this JSON data, do
//
//     final loginResponseModel = loginResponseModelFromJson(jsonString);

import 'dart:convert';

LoginResponseModel loginResponseModelFromJson(String str) => LoginResponseModel.fromJson(json.decode(str));

String loginResponseModelToJson(LoginResponseModel data) => json.encode(data.toJson());

class LoginResponseModel {
  String status;
  Data data;
  String err;

  LoginResponseModel({
    required this.status,
    required this.data,
    required this.err,
  });

  factory LoginResponseModel.fromJson(Map<String, dynamic> json) => LoginResponseModel(
    status: json["status"],
    data: Data.fromJson(json["data"]),
    err: json["err"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "data": data.toJson(),
    "err": err,
  };
}

class Data {
  List<LoginData> data;
  String total;

  Data({
    required this.data,
    required this.total,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    data: List<LoginData>.from(json["data"].map((x) => LoginData.fromJson(x))),
    total: json["total"],
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "total": total,
  };
}

class LoginData {
  String id;
  String type;
  String fname;
  String lname;
  dynamic mname;
  String name;
  String gender;
  dynamic dob;
  String image;
  dynamic doc;
  dynamic details;
  String country;
  String state;
  String city;
  dynamic address;
  dynamic zipcode;
  dynamic latitude;
  dynamic longitude;
  dynamic phone;
  dynamic mobile;
  dynamic fax;
  String company;
  dynamic facebook;
  dynamic twitter;
  dynamic linkedin;
  dynamic youtube;
  dynamic weblink;
  dynamic instagram;
  String email;
  dynamic username;
  String password;
  String ip;
  dynamic referralSourse;
  String active;
  String postdate;
  String refid;
  String zocode;
  String sunday;
  String monday;
  String tuesday;
  String wednesday;
  String thursday;
  String friday;
  String saturday;
  String adminId;
  String userId;
  String brokerId;
  String red;
  String verified;

  LoginData({
    required this.id,
    required this.type,
    required this.fname,
    required this.lname,
    required this.mname,
    required this.name,
    required this.gender,
    required this.dob,
    required this.image,
    required this.doc,
    required this.details,
    required this.country,
    required this.state,
    required this.city,
    required this.address,
    required this.zipcode,
    required this.latitude,
    required this.longitude,
    required this.phone,
    required this.mobile,
    required this.fax,
    required this.company,
    required this.facebook,
    required this.twitter,
    required this.linkedin,
    required this.youtube,
    required this.weblink,
    required this.instagram,
    required this.email,
    required this.username,
    required this.password,
    required this.ip,
    required this.referralSourse,
    required this.active,
    required this.postdate,
    required this.refid,
    required this.zocode,
    required this.sunday,
    required this.monday,
    required this.tuesday,
    required this.wednesday,
    required this.thursday,
    required this.friday,
    required this.saturday,
    required this.adminId,
    required this.userId,
    required this.brokerId,
    required this.red,
    required this.verified,
  });

  factory LoginData.fromJson(Map<String, dynamic> json) => LoginData(
    id: json["id"] == null ? '': json["id"],
    type: json["type"] == null ? '': json["type"],
    fname: json["fname"] == null ? '': json["fname"],
    lname: json["lname"] == null ? '': json["lname"],
    mname: json["mname"] == null ? '': json["mname"],
    name: json["name"] == null ? '': json["name"],
    gender: json["gender"] == null ? '': json["gender"],
    dob: json["dob"] == null ? '': json["dob"],
    image: json["image"] == null ? '': json["image"],
    doc: json["doc"] == null ? '': json["doc"],
    details: json["details"] == null ? '': json["details"],
    country: json["country"] == null ? '': json["country"],
    state: json["state"] == null ? '': json["state"],
    city: json["city"] == null ? '': json["city"],
    address: json["address"] == null ? '': json["address"],
    zipcode: json["zipcode"] == null ? '': json["zipcode"],
    latitude: json["latitude"] == null ? '': json["latitude"],
    longitude: json["longitude"] == null ? '': json["longitude"],
    phone: json["phone"] == null ? '': json["phone"],
    mobile: json["mobile"] == null ? '': json["mobile"],
    fax: json["fax"] == null ? '': json["fax"],
    company: json["company"] == null ? '': json["company"],
    facebook: json["facebook"] == null ? '': json["facebook"],
    twitter: json["twitter"] == null ? '': json["twitter"],
    linkedin: json["linkedin"] == null ? '': json["linkedin"],
    youtube: json["youtube"] == null ? '': json["youtube"],
    weblink: json["weblink"] == null ? '': json["weblink"],
    instagram: json["instagram"] == null ? '': json["instagram"],
    email: json["email"] == null ? '': json["email"],
    username: json["username"] == null ? '': json["username"],
    password: json["password"] == null ? '': json["password"],
    ip: json["ip"] == null ? '': json["ip"],
    referralSourse: json["referral_sourse"] == null ? '': json["referral_sourse"],
    active: json["active"] == null ? '': json["active"],
    postdate: json["postdate"] == null ? '': json["postdate"],
    refid: json["refid"] == null ? '': json["refid"],
    zocode: json["zocode"] == null ? '': json["zocode"],
    sunday: json["sunday"] == null ? '': json["sunday"],
    monday: json["monday"] == null ? '': json["monday"],
    tuesday: json["tuesday"] == null ? '': json["tuesday"],
    wednesday: json["wednesday"] == null ? '': json["wednesday"],
    thursday: json["thursday"] == null ? '': json["thursday"],
    friday: json["friday"] == null ? '': json["friday"],
    saturday: json["saturday"] == null ? '': json["saturday"],
    adminId: json["admin_id"] == null ? '': json["admin_id"],
    userId: json["user_id"],
    brokerId: json["broker_id"] == null ? '': json["broker_id"],
    red: json["red"] == null ? '': json["red"],
    verified: json["verified"] == null ? '': json["verified"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "type": type,
    "fname": fname,
    "lname": lname,
    "mname": mname,
    "name": name,
    "gender": gender,
    "dob": dob,
    "image": image,
    "doc": doc,
    "details": details,
    "country": country,
    "state": state,
    "city": city,
    "address": address,
    "zipcode": zipcode,
    "latitude": latitude,
    "longitude": longitude,
    "phone": phone,
    "mobile": mobile,
    "fax": fax,
    "company": company,
    "facebook": facebook,
    "twitter": twitter,
    "linkedin": linkedin,
    "youtube": youtube,
    "weblink": weblink,
    "instagram": instagram,
    "email": email,
    "username": username,
    "password": password,
    "ip": ip,
    "referral_sourse": referralSourse,
    "active": active,
    "postdate": postdate,
    "refid": refid,
    "zocode": zocode,
    "sunday": sunday,
    "monday": monday,
    "tuesday": tuesday,
    "wednesday": wednesday,
    "thursday": thursday,
    "friday": friday,
    "saturday": saturday,
    "admin_id": adminId,
    "user_id": userId,
    "broker_id": brokerId,
    "red": red,
    "verified": verified,
  };
}
