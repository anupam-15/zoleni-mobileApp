// To parse this JSON data, do
//
//     final countryListModel = countryListModelFromJson(jsonString);

import 'dart:convert';

CountryListModel countryListModelFromJson(String str) => CountryListModel.fromJson(json.decode(str));

String countryListModelToJson(CountryListModel data) => json.encode(data.toJson());

class CountryListModel {
  String status;
  Data data;
  String err;

  CountryListModel({
    required this.status,
    required this.data,
    required this.err,
  });

  factory CountryListModel.fromJson(Map<String, dynamic> json) => CountryListModel(
    status: json["status"],
    data: Data.fromJson(json["data"]),
    err: json["err"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "data": data.toJson(),
    "err": err,
  };
}

class Data {
  List<Datum> data;
  String total;

  Data({
    required this.data,
    required this.total,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    total: json["total"],
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "total": total,
  };
}

class Datum {
  String id;
  String shortcode2;
  String name;
  String phonecode;
  String active;
  String adminId;

  Datum({
    required this.id,
    required this.shortcode2,
    required this.name,
    required this.phonecode,
    required this.active,
    required this.adminId,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    shortcode2: json["shortcode2"],
    name: json["name"],
    phonecode: json["phonecode"],
    active: json["active"],
    adminId: json["admin_id"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "shortcode2": shortcode2,
    "name": name,
    "phonecode": phonecode,
    "active": active,
    "admin_id": adminId,
  };
}
