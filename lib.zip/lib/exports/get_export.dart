export 'package:get/get_core/src/get_main.dart';
export 'package:get/get_navigation/get_navigation.dart';
export 'package:get/get.dart';
