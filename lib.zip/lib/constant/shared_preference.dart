import 'package:get/get.dart';

class SharedPref extends GetxController{
  static String USER_ID = 'id';
  static String USER_IS_LOGIN = 'isLogin';
  static String firstName = 'fName';
  static String lastName = 'lName';
  static String gender = 'gender';
  static String country = 'country';
  static String state = 'state';
  static String city = 'city';
  static String EMAIL = 'email';


}